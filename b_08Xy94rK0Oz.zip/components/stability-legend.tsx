import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { STABILITY_DESCRIPTIONS, type StabilityClass } from "@/lib/stability"
import { STABILITY_COLORS } from "@/lib/stability-colors"
import { cn } from "@/lib/utils"

const ALL_CLASSES: StabilityClass[] = ["A", "B", "C", "D", "E", "F", "G"]

interface StabilityLegendProps {
  activeClass?: StabilityClass
}

export function StabilityLegend({ activeClass }: StabilityLegendProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Категории устойчивости атмосферы</CardTitle>
        <CardDescription>Таблица № 1 РБ-046-21, Приложение № 3</CardDescription>
      </CardHeader>
      <CardContent>
        <ul className="space-y-2">
          {ALL_CLASSES.map((cls) => {
            const colors = STABILITY_COLORS[cls]
            const isActive = activeClass === cls
            return (
              <li
                key={cls}
                className={cn(
                  "flex items-center gap-3 rounded-md border p-2 transition-colors",
                  isActive ? "border-foreground bg-muted" : "border-border",
                )}
              >
                <span
                  className={cn(
                    "flex h-9 w-9 shrink-0 items-center justify-center rounded font-mono text-sm font-bold",
                    colors.bg,
                    colors.text,
                  )}
                >
                  {cls}
                </span>
                <span className="text-sm leading-snug">{STABILITY_DESCRIPTIONS[cls]}</span>
              </li>
            )
          })}
        </ul>
        <p className="mt-4 text-xs text-muted-foreground leading-relaxed">
          Категории F и G часто не разделяются — G включается в F. Характерны для ночных условий при
          температурной инверсии.
        </p>
      </CardContent>
    </Card>
  )
}
