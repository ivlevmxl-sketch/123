import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { STABILITY_DESCRIPTIONS, type StabilityClass } from "@/lib/stability"
import { STABILITY_COLORS } from "@/lib/stability-colors"
import { cn } from "@/lib/utils"

interface ResultDisplayProps {
  stabilityClass: StabilityClass
  method: "turner" | "vogt"
  details?: { label: string; value: string }[]
}

export function ResultDisplay({ stabilityClass, method, details }: ResultDisplayProps) {
  const colors = STABILITY_COLORS[stabilityClass]

  return (
    <Card className="overflow-hidden">
      <CardHeader className="pb-4">
        <div className="flex items-start justify-between gap-4">
          <div>
            <CardDescription className="font-mono text-xs uppercase tracking-wider">
              Результат — {method === "turner" ? "Паскуилл–Тернер" : "Паскуилл–Фогт"}
            </CardDescription>
            <CardTitle className="mt-1 text-pretty">Категория устойчивости атмосферы</CardTitle>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        <div
          className={cn(
            "flex items-center gap-6 rounded-lg border-2 p-6",
            colors.border,
          )}
        >
          <div
            className={cn(
              "flex h-24 w-24 shrink-0 items-center justify-center rounded-lg font-mono text-5xl font-bold shadow-sm",
              colors.bg,
              colors.text,
            )}
            aria-label={`Категория ${stabilityClass}`}
          >
            {stabilityClass}
          </div>

          <div className="flex-1">
            <p className="text-pretty text-lg font-medium leading-snug">
              {STABILITY_DESCRIPTIONS[stabilityClass]}
            </p>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
              {getCategoryExplanation(stabilityClass)}
            </p>
          </div>
        </div>

        {details && details.length > 0 && (
          <div>
            <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
              Промежуточные значения
            </h3>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              {details.map((d) => (
                <div
                  key={d.label}
                  className="flex items-center justify-between rounded-md border bg-muted/30 px-3 py-2"
                >
                  <span className="text-sm text-muted-foreground">{d.label}</span>
                  <Badge variant="secondary" className="font-mono">
                    {d.value}
                  </Badge>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

function getCategoryExplanation(cls: StabilityClass): string {
  switch (cls) {
    case "A":
      return "Интенсивное вертикальное перемешивание. Примесь быстро рассеивается в вертикальном направлении."
    case "B":
      return "Выраженная неустойчивость. Активное турбулентное перемешивание, типичное для ясного дня."
    case "C":
      return "Слабая неустойчивость. Умеренное перемешивание, характерно для облачного дня или утра."
    case "D":
      return "Безразличная стратификация. Типично для пасмурной погоды или сильного ветра."
    case "E":
      return "Слабая устойчивость. Пониженное перемешивание, характерно для вечера."
    case "F":
      return "Устойчивая стратификация. Слабое перемешивание, ночные условия с инверсией."
    case "G":
      return "Сильная устойчивость. Очень слабое перемешивание, ночная инверсия в нижнем слое атмосферы."
  }
}
