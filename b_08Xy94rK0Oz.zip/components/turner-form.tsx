"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { pasquillTurner, type TurnerInput, type TurnerResult } from "@/lib/stability"
import { Calculator, Sun } from "lucide-react"

interface TurnerFormProps {
  onResult: (result: TurnerResult, input: TurnerInput) => void
}

export function TurnerForm({ onResult }: TurnerFormProps) {
  const now = new Date()
  const [form, setForm] = useState<TurnerInput>({
    latitude: 55.75,
    longitude: 37.62,
    day: now.getDate(),
    month: now.getMonth() + 1,
    year: now.getFullYear(),
    moscowTime: 12,
    windSpeed: 3,
    totalClouds: 2,
    lowerClouds: 0,
    fog: false,
    snowCover: false,
  })

  const update = <K extends keyof TurnerInput>(key: K, value: TurnerInput[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const result = pasquillTurner(form)
    onResult(result, form)
  }

  const handleClickButton = () => {
    const result = pasquillTurner(form)
    onResult(result, form)
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 text-primary">
            <Sun className="h-5 w-5" aria-hidden="true" />
          </div>
          <div>
            <CardTitle>Метод Паскуилла – Тернера</CardTitle>
            <CardDescription>
              Расчёт по высоте солнца, инсоляции, облачности и скорости ветра
            </CardDescription>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <fieldset className="space-y-4">
            <legend className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
              Географическое положение
            </legend>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="latitude">Широта ψ, °</Label>
                <Input
                  id="latitude"
                  type="number"
                  step="0.01"
                  min={-90}
                  max={90}
                  value={form.latitude}
                  onChange={(e) => update("latitude", Number.parseFloat(e.target.value) || 0)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="longitude">Долгота λ, °</Label>
                <Input
                  id="longitude"
                  type="number"
                  step="0.01"
                  min={-180}
                  max={180}
                  value={form.longitude}
                  onChange={(e) => update("longitude", Number.parseFloat(e.target.value) || 0)}
                />
              </div>
            </div>
          </fieldset>

          <fieldset className="space-y-4">
            <legend className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
              Дата и время
            </legend>
            <div className="grid gap-4 sm:grid-cols-4">
              <div className="space-y-2">
                <Label htmlFor="day">День</Label>
                <Input
                  id="day"
                  type="number"
                  min={1}
                  max={31}
                  value={form.day}
                  onChange={(e) => update("day", Number.parseInt(e.target.value) || 1)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="month">Месяц</Label>
                <Input
                  id="month"
                  type="number"
                  min={1}
                  max={12}
                  value={form.month}
                  onChange={(e) => update("month", Number.parseInt(e.target.value) || 1)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="year">Год</Label>
                <Input
                  id="year"
                  type="number"
                  min={1900}
                  max={2100}
                  value={form.year}
                  onChange={(e) => update("year", Number.parseInt(e.target.value) || 2024)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="moscowTime">Мск. время, ч</Label>
                <Input
                  id="moscowTime"
                  type="number"
                  step="0.25"
                  min={0}
                  max={24}
                  value={form.moscowTime}
                  onChange={(e) => update("moscowTime", Number.parseFloat(e.target.value) || 0)}
                />
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              Московское время без сезонного сдвига (UTC+3).
            </p>
          </fieldset>

          <fieldset className="space-y-4">
            <legend className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
              Метеорологические параметры
            </legend>
            <div className="grid gap-4 sm:grid-cols-3">
              <div className="space-y-2">
                <Label htmlFor="windSpeed">
                  Скорость ветра u<sub>f</sub>, м/с
                </Label>
                <Input
                  id="windSpeed"
                  type="number"
                  step="0.1"
                  min={0}
                  value={form.windSpeed}
                  onChange={(e) => update("windSpeed", Number.parseFloat(e.target.value) || 0)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="totalClouds">
                  Общая облачность N<sub>0</sub>, балл.
                </Label>
                <Input
                  id="totalClouds"
                  type="number"
                  min={0}
                  max={10}
                  value={form.totalClouds}
                  onChange={(e) => update("totalClouds", Number.parseInt(e.target.value) || 0)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lowerClouds">
                  Нижняя облачность N<sub>n</sub>, балл.
                </Label>
                <Input
                  id="lowerClouds"
                  type="number"
                  min={0}
                  max={10}
                  value={form.lowerClouds}
                  onChange={(e) => update("lowerClouds", Number.parseInt(e.target.value) || 0)}
                />
              </div>
            </div>

            <div className="flex flex-wrap gap-6 pt-2">
              <div className="flex items-center gap-2">
                <Checkbox
                  id="fog"
                  checked={form.fog}
                  onCheckedChange={(v) => update("fog", Boolean(v))}
                />
                <Label htmlFor="fog" className="cursor-pointer font-normal">
                  Сильный туман (видимость {"< 1"} км)
                </Label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="snowCover"
                  checked={form.snowCover}
                  onCheckedChange={(v) => update("snowCover", Boolean(v))}
                />
                <Label htmlFor="snowCover" className="cursor-pointer font-normal">
                  Сплошной снежный покров
                </Label>
              </div>
            </div>
          </fieldset>

          <Button type="submit" onClick={handleClickButton} className="w-full sm:w-auto">
            <Calculator className="mr-2 h-4 w-4" />
            Рассчитать категорию
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
