"use client"

import { useState } from "react"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { TurnerForm } from "./turner-form"
import { VogtForm } from "./vogt-form"
import { ResultDisplay } from "./result-display"
import { DispersionChart } from "./dispersion-chart"
import { StabilityLegend } from "./stability-legend"
import type { StabilityClass, TurnerInput, TurnerResult, VogtInput, VogtResult } from "@/lib/stability"
import { Card, CardContent } from "@/components/ui/card"
import { Info } from "lucide-react"

export function StabilityCalculator() {
  const [method, setMethod] = useState<"turner" | "vogt">("turner")
  const [turnerResult, setTurnerResult] = useState<{ result: TurnerResult; input: TurnerInput } | null>(null)
  const [vogtResult, setVogtResult] = useState<{ result: VogtResult; input: VogtInput } | null>(null)

  const activeClass: StabilityClass | undefined =
    method === "turner" ? turnerResult?.result.stabilityClass : vogtResult?.result.stabilityClass

  const turnerDetails = turnerResult
    ? [
        { label: "День года d", value: `${turnerResult.result.dayOfYear}` },
        { label: "Солнечное склонение δ", value: `${((turnerResult.result.solarDeclination * 180) / Math.PI).toFixed(2)}°` },
        { label: "Истинное местное время t_им", value: `${turnerResult.result.localSolarTime.toFixed(2)} ч` },
        { label: "Высота солнца h₀", value: `${turnerResult.result.solarElevation.toFixed(2)}°` },
        { label: "Время захода t_им.з", value: `${turnerResult.result.sunsetTime.toFixed(2)} ч` },
        { label: "День/ночь", value: turnerResult.result.isDaytime ? "День" : "Ночь" },
        { label: "Индекс инсоляции n_I", value: `${turnerResult.result.rawInsolationIndex}` },
        { label: "Шифр поправки", value: turnerResult.result.cloudCorrectionCode },
        { label: "Исправленный n_I'", value: `${turnerResult.result.correctedInsolationIndex}` },
      ]
    : []

  const vogtDetails = vogtResult
    ? [
        { label: "Диапазон градиента", value: vogtResult.result.gradientBucket + " °C/100м" },
        { label: "Диапазон скорости ветра", value: vogtResult.result.windBucket + " м/с" },
      ]
    : []

  return (
    <div className="space-y-6">
      <Tabs value={method} onValueChange={(v) => setMethod(v as "turner" | "vogt")}>
        <TabsList className="grid w-full grid-cols-2 sm:w-auto sm:inline-grid">
          <TabsTrigger value="turner">Паскуилл–Тернер</TabsTrigger>
          <TabsTrigger value="vogt">Паскуилл–Фогт</TabsTrigger>
        </TabsList>

        <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_320px]">
          <div className="space-y-6">
            <TabsContent value="turner" className="mt-0 space-y-6">
              <TurnerForm onResult={(result, input) => setTurnerResult({ result, input })} />
              {turnerResult ? (
                <ResultDisplay
                  stabilityClass={turnerResult.result.stabilityClass}
                  method="turner"
                  details={turnerDetails}
                />
              ) : (
                <EmptyHint text="Заполните параметры выше и нажмите «Рассчитать категорию»." />
              )}
            </TabsContent>

            <TabsContent value="vogt" className="mt-0 space-y-6">
              <VogtForm onResult={(result, input) => setVogtResult({ result, input })} />
              {vogtResult ? (
                <ResultDisplay
                  stabilityClass={vogtResult.result.stabilityClass}
                  method="vogt"
                  details={vogtDetails}
                />
              ) : (
                <EmptyHint text="Введите вертикальный градиент температуры и скорость ветра." />
              )}
            </TabsContent>

            <DispersionChart activeClass={activeClass} />
          </div>

          <aside className="space-y-6">
            <StabilityLegend activeClass={activeClass} />
          </aside>
        </div>
      </Tabs>
    </div>
  )
}

function EmptyHint({ text }: { text: string }) {
  return (
    <Card className="border-dashed">
      <CardContent className="flex items-center gap-3 py-6 text-sm text-muted-foreground">
        <Info className="h-4 w-4 shrink-0" aria-hidden="true" />
        <span>{text}</span>
      </CardContent>
    </Card>
  )
}
