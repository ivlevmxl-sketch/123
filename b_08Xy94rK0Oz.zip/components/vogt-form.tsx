"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { pasquillVogt, type VogtInput, type VogtResult } from "@/lib/stability"
import { Calculator, Thermometer } from "lucide-react"

interface VogtFormProps {
  onResult: (result: VogtResult, input: VogtInput) => void
}

export function VogtForm({ onResult }: VogtFormProps) {
  const [form, setForm] = useState<VogtInput>({
    gradient: 0.65,
    windSpeed: 3,
  })

  const update = <K extends keyof VogtInput>(key: K, value: VogtInput[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const result = pasquillVogt(form)
    onResult(result, form)
  }

  const handleClickButton = () => {
    const result = pasquillVogt(form)
    onResult(result, form)
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 text-primary">
            <Thermometer className="h-5 w-5" aria-hidden="true" />
          </div>
          <div>
            <CardTitle>Метод Паскуилла – Фогта</CardTitle>
            <CardDescription>
              Расчёт по вертикальному градиенту температуры в слое 0–300 м и скорости ветра
            </CardDescription>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="gradient">
                Градиент γ = −ΔT/Δz, °C / 100 м
              </Label>
              <Input
                id="gradient"
                type="number"
                step="0.01"
                value={form.gradient}
                onChange={(e) => update("gradient", Number.parseFloat(e.target.value) || 0)}
              />
              <p className="text-xs text-muted-foreground">
                Сухоадиабатический градиент ≈ 0,98 °C/100 м. Положительные значения — падение T с высотой.
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="windSpeedV">Скорость ветра V, м/с</Label>
              <Input
                id="windSpeedV"
                type="number"
                step="0.1"
                min={0}
                value={form.windSpeed}
                onChange={(e) => update("windSpeed", Number.parseFloat(e.target.value) || 0)}
              />
              <p className="text-xs text-muted-foreground">На уровне флюгера (анемометра).</p>
            </div>
          </div>

          <div className="rounded-md border bg-muted/30 p-4">
            <h4 className="mb-2 text-sm font-semibold">Справка по градиентам:</h4>
            <ul className="space-y-1 text-xs text-muted-foreground">
              <li>
                <span className="font-mono">γ ≥ 1,2</span> — сверхадиабатический, сильная неустойчивость
              </li>
              <li>
                <span className="font-mono">0,6 ≤ γ &lt; 1,0</span> — близко к нейтральному (D)
              </li>
              <li>
                <span className="font-mono">0,0 ≤ γ &lt; 0,6</span> — слабая устойчивость
              </li>
              <li>
                <span className="font-mono">γ &lt; 0</span> — инверсия (температура растёт с высотой)
              </li>
            </ul>
          </div>

          <Button type="submit" onClick={handleClickButton} className="w-full sm:w-auto">
            <Calculator className="mr-2 h-4 w-4" />
            Рассчитать категорию
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
