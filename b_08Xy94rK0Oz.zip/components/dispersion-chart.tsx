"use client"

import { useMemo, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/components/ui/chart"
import { CartesianGrid, Line, LineChart, XAxis, YAxis, ReferenceDot, Legend } from "recharts"
import { sigmaZ, type StabilityClass } from "@/lib/stability"
import { STABILITY_COLORS } from "@/lib/stability-colors"

interface DispersionChartProps {
  activeClass?: StabilityClass
}

const CLASSES: Array<"A" | "B" | "C" | "D" | "E" | "F"> = ["A", "B", "C", "D", "E", "F"]

// Набор расстояний по логарифмической сетке 10 – 10000 м
const DISTANCES = (() => {
  const arr: number[] = []
  for (let x = 1; x <= 4.01; x += 0.1) {
    arr.push(Math.round(Math.pow(10, x)))
  }
  return Array.from(new Set(arr))
})()

export function DispersionChart({ activeClass }: DispersionChartProps) {
  const [height, setHeight] = useState<"50" | "100">("50")

  const data = useMemo(() => {
    return DISTANCES.map((r) => {
      const row: Record<string, number> = { r }
      for (const cls of CLASSES) {
        row[cls] = sigmaZ(r, cls, height)
      }
      return row
    })
  }, [height])

  const config: ChartConfig = useMemo(() => {
    const conf: ChartConfig = {}
    for (const cls of CLASSES) {
      conf[cls] = {
        label: `Класс ${cls}`,
        color: STABILITY_COLORS[cls].hex,
      }
    }
    return conf
  }, [])

  // Если активный класс не A–F (т.е. G), отобразим F как ближайший
  const highlightClass: "A" | "B" | "C" | "D" | "E" | "F" | null =
    activeClass && activeClass !== "G" ? activeClass : activeClass === "G" ? "F" : null

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <CardTitle>Параметр вертикальной дисперсии σ<sub>z</sub>(r)</CardTitle>
            <CardDescription className="mt-1 text-pretty">
              σ<sub>z,l</sub> = p<sub>l</sub> · exp(q<sub>l</sub> · ln r), по таблице № 8 РБ-046-21
            </CardDescription>
          </div>

          <Tabs value={height} onValueChange={(v) => setHeight(v as "50" | "100")}>
            <TabsList>
              <TabsTrigger value="50">H = 50 м</TabsTrigger>
              <TabsTrigger value="100">H = 100 м</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </CardHeader>

      <CardContent>
        <ChartContainer config={config} className="aspect-auto h-[380px] w-full">
          <LineChart data={data} margin={{ top: 8, right: 16, left: 8, bottom: 8 }}>
            <CartesianGrid vertical={false} strokeDasharray="3 3" />
            <XAxis
              dataKey="r"
              scale="log"
              domain={[10, 10000]}
              type="number"
              ticks={[10, 100, 1000, 10000]}
              tickFormatter={(v) => `${v} м`}
              stroke="currentColor"
              className="text-xs"
            />
            <YAxis
              scale="log"
              domain={[0.1, "auto"]}
              type="number"
              allowDataOverflow
              tickFormatter={(v) => `${v}`}
              stroke="currentColor"
              className="text-xs"
              label={{
                value: "σz, м",
                angle: -90,
                position: "insideLeft",
                style: { fill: "currentColor", fontSize: 12 },
              }}
            />
            <ChartTooltip
              content={
                <ChartTooltipContent
                  labelFormatter={(label) => `r = ${label} м`}
                  formatter={(value, name) => [`${(value as number).toFixed(2)} м`, ` ${name}`]}
                />
              }
            />
            <Legend
              wrapperStyle={{ paddingTop: 8, fontSize: 12 }}
              iconType="line"
            />
            {CLASSES.map((cls) => {
              const isActive = highlightClass === cls
              return (
                <Line
                  key={cls}
                  type="monotone"
                  dataKey={cls}
                  name={`Класс ${cls}`}
                  stroke={STABILITY_COLORS[cls].hex}
                  strokeWidth={isActive ? 3 : 1.5}
                  strokeOpacity={highlightClass && !isActive ? 0.35 : 1}
                  dot={false}
                  isAnimationActive={false}
                />
              )
            })}
            {highlightClass &&
              [100, 1000].map((r) => (
                <ReferenceDot
                  key={r}
                  x={r}
                  y={sigmaZ(r, highlightClass, height)}
                  r={4}
                  fill={STABILITY_COLORS[highlightClass].hex}
                  stroke="var(--background)"
                  strokeWidth={2}
                />
              ))}
          </LineChart>
        </ChartContainer>

        {highlightClass && (
          <div className="mt-4 grid gap-2 text-sm sm:grid-cols-3">
            {[100, 500, 1000].map((r) => (
              <div
                key={r}
                className="flex items-center justify-between rounded-md border bg-muted/30 px-3 py-2"
              >
                <span className="text-muted-foreground">
                  σ<sub>z</sub> при r = {r} м
                </span>
                <span className="font-mono font-medium">
                  {sigmaZ(r, highlightClass, height).toFixed(2)} м
                </span>
              </div>
            ))}
          </div>
        )}

        {activeClass === "G" && (
          <p className="mt-3 text-xs text-muted-foreground">
            Примечание: для класса G используются константы класса F (РБ-046-21, прим. к таблице № 1).
          </p>
        )}
      </CardContent>
    </Card>
  )
}
