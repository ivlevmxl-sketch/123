// Методика определения категорий устойчивости атмосферы
// согласно РБ-046-21, Приложение № 3, пункт 2

export type StabilityClass = "A" | "B" | "C" | "D" | "E" | "F" | "G"

export const STABILITY_DESCRIPTIONS: Record<StabilityClass, string> = {
  A: "Сильная конвекция атмосферы",
  B: "Умеренно неустойчивые условия",
  C: "Слабая неустойчивость атмосферы",
  D: "Нейтральные условия (безразличная стратификация)",
  E: "Слабо устойчивая атмосфера",
  F: "Умеренно устойчивая атмосфера",
  G: "Сильная устойчивость атмосферы",
}

// ======================================================================
// МЕТОД ПАСКУИЛЛА – ТЕРНЕРА (п. 2.1 Приложения № 3)
// ======================================================================

export interface TurnerInput {
  latitude: number // широта ψ, град
  longitude: number // долгота λ, град
  day: number // dd
  month: number // mm
  year: number // jjjj
  moscowTime: number // t_мв, ч (московское время без сезонного сдвига)
  windSpeed: number // u_f, м/с (скорость ветра на флюгере)
  totalClouds: number // N0, баллы 0–10 (общая облачность)
  lowerClouds: number // Nn, баллы 0–10 (нижняя облачность)
  fog: boolean // сильный туман (видимость < 1 км)
  snowCover: boolean // сплошной снежный покров
}

export interface TurnerResult {
  dayOfYear: number
  solarDeclination: number // δ, рад
  solarLongitude: number // S_L, рад
  hourAngle: number // α_h, рад
  solarElevation: number // h0, град
  localSolarTime: number // t_им, ч
  sunsetTime: number // t_им.з, ч
  hoursAfterSunset: number | null
  isDaytime: boolean
  rawInsolationIndex: number // n_I из таблицы 2
  cloudCorrectionCode: "I" | "II" | "III" | "IV" | "V" | "VI" | "VII"
  correctedInsolationIndex: number // n_I'
  stabilityClass: StabilityClass
}

// Порядковый день года
function dayOfYear(day: number, month: number, year: number): number {
  const d = new Date(Date.UTC(year, month - 1, day))
  const start = new Date(Date.UTC(year, 0, 1))
  return Math.floor((d.getTime() - start.getTime()) / 86400000) + 1
}

// п. 2.1.3: вычисление высоты солнца и времени захода
export function computeSolarGeometry(input: Pick<TurnerInput, "latitude" | "longitude" | "day" | "month" | "year" | "moscowTime">) {
  const psi = (input.latitude * Math.PI) / 180 // широта в рад
  const lambda = (input.longitude * Math.PI) / 180 // долгота в рад
  const d = dayOfYear(input.day, input.month, input.year)

  // (3) Долгота солнца
  const S_L = 4.90877 + 0.0170542 * d

  // (2) Солнечное склонение
  const sinDelta = 0.39795 * Math.sin(S_L)
  const delta = Math.asin(sinDelta)

  // (5) Истинное местное (солнечное) время
  // t_им = t_мв - 3 + λ/15 (часовой пояс Москвы = UTC+3, λ в градусах)
  // В радианах: t_им = t_мв - 3 + λ*180/(π*15)
  const lambdaDeg = input.longitude
  const t_im = input.moscowTime - 3 + lambdaDeg / 15

  // (4) Часовой угол α_h = (t_им - 12) * π / 12
  const alpha_h = ((t_im - 12) * Math.PI) / 12

  // (1) Высота солнца
  const sin_h0 = Math.sin(delta) * Math.sin(psi) + Math.cos(delta) * Math.cos(psi) * Math.cos(alpha_h)
  const h0Rad = Math.asin(Math.max(-1, Math.min(1, sin_h0)))
  const h0Deg = (h0Rad * 180) / Math.PI

  // (6) Время захода солнца (при высоте центра ~ -50' с учетом размера солнца и рефракции)
  // cos(α_h_заход) = (sin(-50') - sinδ·sinψ) / (cosδ·cosψ)
  const sunsetAltitude = (-50 / 60) * (Math.PI / 180) // -50 угл. мин
  const cosAlphaSunset =
    (Math.sin(sunsetAltitude) - Math.sin(delta) * Math.sin(psi)) / (Math.cos(delta) * Math.cos(psi))
  let sunsetTime = 24
  if (cosAlphaSunset >= -1 && cosAlphaSunset <= 1) {
    const alphaSunset = Math.acos(cosAlphaSunset)
    sunsetTime = 12 + (alphaSunset * 12) / Math.PI
  }

  return {
    dayOfYear: d,
    solarDeclination: delta,
    solarLongitude: S_L,
    hourAngle: alpha_h,
    solarElevation: h0Deg,
    localSolarTime: t_im,
    sunsetTime,
  }
}

// Таблица № 2: индекс инсоляции n_I
function getInsolationIndex(
  solarElevationDeg: number,
  localSolarTime: number,
  sunsetTime: number,
): { nI: number; hoursAfterSunset: number | null; isDaytime: boolean } {
  // День: солнце выше горизонта
  if (solarElevationDeg > 0) {
    // Проверка на "в течение 1 ч до захода и после восхода"
    const hoursBeforeSunset = sunsetTime - localSolarTime
    const sunriseTime = 24 - sunsetTime
    const hoursAfterSunrise = localSolarTime - sunriseTime
    const nearSunriseOrSunset =
      (hoursBeforeSunset > 0 && hoursBeforeSunset <= 1) || (hoursAfterSunrise >= 0 && hoursAfterSunrise <= 1)

    if (nearSunriseOrSunset) {
      return { nI: -1, hoursAfterSunset: null, isDaytime: true }
    }

    if (solarElevationDeg <= 15) return { nI: 1, hoursAfterSunset: null, isDaytime: true }
    if (solarElevationDeg <= 30) return { nI: 2, hoursAfterSunset: null, isDaytime: true }
    if (solarElevationDeg <= 45) return { nI: 3, hoursAfterSunset: null, isDaytime: true }
    if (solarElevationDeg <= 60) return { nI: 4, hoursAfterSunset: null, isDaytime: true }
    return { nI: 5, hoursAfterSunset: null, isDaytime: true }
  }

  // Ночь: солнце ниже горизонта
  let hoursAfterSunset = localSolarTime - sunsetTime
  if (hoursAfterSunset < 0) hoursAfterSunset += 24
  if (hoursAfterSunset > 12) hoursAfterSunset = 24 - hoursAfterSunset

  if (hoursAfterSunset <= 2) return { nI: -1, hoursAfterSunset, isDaytime: false }
  if (hoursAfterSunset <= 7) return { nI: -2, hoursAfterSunset, isDaytime: false }
  return { nI: -3, hoursAfterSunset, isDaytime: false }
}

// Таблица № 3: шифр поправки на облачность
// Практическая интерпретация: оценивается день/ночь и облачность
function getCloudCorrectionCode(
  totalClouds: number,
  lowerClouds: number,
  isDaytime: boolean,
  fog: boolean,
): "I" | "II" | "III" | "IV" | "V" | "VI" {
  if (fog) return "VI"

  // Низкая облачность 9–10 баллов → шифр V (сплошная низкая)
  if (lowerClouds >= 9) return "V"

  if (isDaytime) {
    // День: чем больше облачность, тем выше шифр
    if (totalClouds <= 3 && lowerClouds <= 3) return "I"
    if (totalClouds <= 6 && lowerClouds <= 5) return "II"
    if (totalClouds <= 8 && lowerClouds <= 6) return "III"
    return "IV"
  } else {
    // Ночь: сильная облачность делает ночь менее устойчивой
    if (totalClouds <= 3) return "I"
    if (totalClouds <= 6) return "II"
    if (totalClouds <= 8) return "III"
    return "IV"
  }
}

// Таблица № 4: индекс инсоляции n_I' с поправками
// Столбцы: n_I ∈ {-3, -2, -1, 1, 2, 3, 4, 5}
const TABLE_4: Record<"I" | "II" | "III" | "IV" | "V" | "VI" | "VII", Record<number, number>> = {
  I: { "-3": -3, "-2": -2, "-1": -1, 1: 1, 2: 2, 3: 3, 4: 4, 5: 5 },
  II: { "-3": -2, "-2": -1, "-1": -1, 1: 1, 2: 1, 3: 2, 4: 3, 5: 4 },
  III: { "-3": -1, "-2": -1, "-1": -1, 1: 1, 2: 1, 3: 2, 4: 3, 5: 4 },
  IV: { "-3": -1, "-2": -1, "-1": -1, 1: 1, 2: 1, 3: 1, 4: 2, 5: 3 },
  V: { "-3": 0, "-2": 0, "-1": 0, 1: 0, 2: 1, 3: 1, 4: 1, 5: 2 },
  VI: { "-3": 0, "-2": 0, "-1": 0, 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 },
  VII: { "-3": -3, "-2": -3, "-1": -2, 1: -1, 2: 1, 3: 2, 4: 3, 5: 3 },
}

function applyCloudCorrection(nI: number, code: "I" | "II" | "III" | "IV" | "V" | "VI"): number {
  // n_I = 0 специальное значение (час до захода при ярком свете) — не корректируем
  if (nI === 0) return 0
  const row = TABLE_4[code]
  return row[nI.toString() as keyof typeof row] ?? nI
}

// Таблица № 5: класс устойчивости по u_f и n_I'
// Строки: u_f (м/с): 0–1, 2, 3, 4, 5, 6, 7, ≥8
// Столбцы: n_I' ∈ {-3, -2, -1, 0, 1, 2, 3, 4, 5}
const TABLE_5: StabilityClass[][] = [
  // -3  -2  -1   0   1   2   3   4   5
  ["G", "G", "F", "D", "C", "B", "A", "A", "A"], // 0–1
  ["G", "F", "E", "D", "C", "B", "B", "A", "A"], // 2
  ["F", "F", "E", "D", "C", "C", "B", "B", "A"], // 3
  ["F", "E", "D", "D", "D", "C", "B", "B", "A"], // 4
  ["E", "E", "D", "D", "D", "C", "C", "B", "B"], // 5
  ["E", "D", "D", "D", "D", "C", "C", "C", "B"], // 6
  ["E", "D", "D", "D", "D", "D", "C", "C", "B"], // 7
  ["D", "D", "D", "D", "D", "D", "D", "D", "C"], // ≥8
]

function getStabilityClassFromTable5(windSpeed: number, nIcorrected: number): StabilityClass {
  let row: number
  if (windSpeed <= 1) row = 0
  else if (windSpeed < 2.5) row = 1
  else if (windSpeed < 3.5) row = 2
  else if (windSpeed < 4.5) row = 3
  else if (windSpeed < 5.5) row = 4
  else if (windSpeed < 6.5) row = 5
  else if (windSpeed < 7.5) row = 6
  else row = 7

  const col = Math.max(0, Math.min(8, nIcorrected + 3)) // -3→0, 5→8
  return TABLE_5[row][col]
}

// Главная функция метода Паскуилла – Тернера
export function pasquillTurner(input: TurnerInput): TurnerResult {
  const geom = computeSolarGeometry(input)

  const { nI, hoursAfterSunset, isDaytime } = getInsolationIndex(
    geom.solarElevation,
    geom.localSolarTime,
    geom.sunsetTime,
  )

  let code = getCloudCorrectionCode(input.totalClouds, input.lowerClouds, isDaytime, input.fog)

  let nIcorrected = applyCloudCorrection(nI, code)

  // Поправка на снеговой покров (шифр VII) — применяется после облачности
  if (input.snowCover && !input.fog) {
    const snowCorrected = TABLE_4.VII[nI.toString() as keyof (typeof TABLE_4)["VII"]]
    if (snowCorrected !== undefined) {
      nIcorrected = snowCorrected
      code = "VII" as typeof code & "VII"
    }
  }

  const stabilityClass = getStabilityClassFromTable5(input.windSpeed, nIcorrected)

  return {
    dayOfYear: geom.dayOfYear,
    solarDeclination: geom.solarDeclination,
    solarLongitude: geom.solarLongitude,
    hourAngle: geom.hourAngle,
    solarElevation: geom.solarElevation,
    localSolarTime: geom.localSolarTime,
    sunsetTime: geom.sunsetTime,
    hoursAfterSunset,
    isDaytime,
    rawInsolationIndex: nI,
    cloudCorrectionCode: code,
    correctedInsolationIndex: nIcorrected,
    stabilityClass,
  }
}

// ======================================================================
// МЕТОД ПАСКУИЛЛА – ФОГТА (п. 2.2 Приложения № 3)
// ======================================================================

export interface VogtInput {
  gradient: number // γ = -ΔT/Δz, °C/100 м, слой 0–300 м
  windSpeed: number // V на уровне флюгера (анемометра), м/с
}

export interface VogtResult {
  stabilityClass: StabilityClass
  gradientBucket: string
  windBucket: string
}

// Таблица № 7
// Строки: V — градации скорости
// Столбцы: γ ≥ 1.2 | 1.0–1.2 | 0.8–1.0 | 0.6–0.8 | 0.0–0.6 | -1.4–0.0 | γ < -1.4
const TABLE_7: StabilityClass[][] = [
  ["A", "A", "B", "C", "D", "F", "F"], // V < 1
  ["A", "B", "B", "C", "D", "F", "F"], // 1 ≤ V < 2
  ["A", "B", "C", "D", "D", "E", "F"], // 2 ≤ V < 3
  ["B", "B", "C", "D", "D", "D", "E"], // 3 ≤ V < 5
  ["C", "C", "D", "D", "D", "D", "E"], // 5 ≤ V < 7
  ["D", "D", "D", "D", "D", "D", "D"], // V ≥ 7
]

const GRADIENT_LABELS = ["γ ≥ 1.2", "1.0 ≤ γ < 1.2", "0.8 ≤ γ < 1.0", "0.6 ≤ γ < 0.8", "0.0 ≤ γ < 0.6", "-1.4 ≤ γ < 0.0", "γ < -1.4"]
const WIND_LABELS = ["V < 1", "1 ≤ V < 2", "2 ≤ V < 3", "3 ≤ V < 5", "5 ≤ V < 7", "V ≥ 7"]

export function pasquillVogt(input: VogtInput): VogtResult {
  const { gradient: g, windSpeed: v } = input

  let gCol: number
  if (g >= 1.2) gCol = 0
  else if (g >= 1.0) gCol = 1
  else if (g >= 0.8) gCol = 2
  else if (g >= 0.6) gCol = 3
  else if (g >= 0.0) gCol = 4
  else if (g >= -1.4) gCol = 5
  else gCol = 6

  let vRow: number
  if (v < 1) vRow = 0
  else if (v < 2) vRow = 1
  else if (v < 3) vRow = 2
  else if (v < 5) vRow = 3
  else if (v < 7) vRow = 4
  else vRow = 5

  return {
    stabilityClass: TABLE_7[vRow][gCol],
    gradientBucket: GRADIENT_LABELS[gCol],
    windBucket: WIND_LABELS[vRow],
  }
}

// ======================================================================
// ПАРАМЕТР ВЕРТИКАЛЬНОЙ ДИСПЕРСИИ σ_z(r) (п. 2.2.2, таблица № 8)
// ======================================================================

// σ_z,l = p_l · exp(q_l · ln r),  r и σ_z в метрах

export const DISPERSION_CONSTANTS: Record<
  "50" | "100",
  Record<"A" | "B" | "C" | "D" | "E" | "F", { p: number; q: number }>
> = {
  "50": {
    A: { p: 0.22, q: 0.97 },
    B: { p: 0.22, q: 0.97 },
    C: { p: 0.21, q: 0.94 },
    D: { p: 0.2, q: 0.94 },
    E: { p: 0.16, q: 0.81 },
    F: { p: 0.4, q: 0.62 },
  },
  "100": {
    A: { p: 0.1, q: 1.16 },
    B: { p: 0.16, q: 1.02 },
    C: { p: 0.25, q: 0.89 },
    D: { p: 0.4, q: 0.76 },
    E: { p: 0.16, q: 0.81 },
    F: { p: 0.4, q: 0.62 },
  },
}

export function sigmaZ(r: number, cls: "A" | "B" | "C" | "D" | "E" | "F", height: "50" | "100"): number {
  const { p, q } = DISPERSION_CONSTANTS[height][cls]
  return p * Math.exp(q * Math.log(r))
}
