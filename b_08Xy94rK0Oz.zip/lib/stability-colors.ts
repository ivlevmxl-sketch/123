import type { StabilityClass } from "./stability"

// Цвета для визуализации категорий от конвекции (тёплый) к устойчивости (холодный)
export const STABILITY_COLORS: Record<StabilityClass, { bg: string; text: string; border: string; hex: string }> = {
  A: { bg: "bg-red-500", text: "text-white", border: "border-red-600", hex: "#ef4444" },
  B: { bg: "bg-orange-500", text: "text-white", border: "border-orange-600", hex: "#f97316" },
  C: { bg: "bg-amber-400", text: "text-amber-950", border: "border-amber-500", hex: "#fbbf24" },
  D: { bg: "bg-slate-400", text: "text-white", border: "border-slate-500", hex: "#94a3b8" },
  E: { bg: "bg-sky-500", text: "text-white", border: "border-sky-600", hex: "#0ea5e9" },
  F: { bg: "bg-blue-700", text: "text-white", border: "border-blue-800", hex: "#1d4ed8" },
  G: { bg: "bg-indigo-900", text: "text-white", border: "border-indigo-950", hex: "#312e81" },
}
