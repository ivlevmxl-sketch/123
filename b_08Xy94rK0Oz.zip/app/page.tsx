import { StabilityCalculator } from "@/components/stability-calculator"
import { Wind } from "lucide-react"

export default function Page() {
  return (
    <main className="min-h-screen bg-background">
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 sm:py-10 lg:py-12">
        <header className="mb-8 flex flex-col gap-4 border-b pb-8 sm:flex-row sm:items-start sm:justify-between">
          <div className="flex items-start gap-4">
            <div
              className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-primary text-primary-foreground"
              aria-hidden="true"
            >
              <Wind className="h-6 w-6" />
            </div>
            <div>
              <p className="font-mono text-xs uppercase tracking-wider text-muted-foreground">
                РБ-046-21 · Приложение № 3
              </p>
              <h1 className="mt-1 text-balance text-2xl font-semibold tracking-tight sm:text-3xl">
                Категории устойчивости атмосферы
              </h1>
              <p className="mt-2 max-w-2xl text-pretty text-sm text-muted-foreground leading-relaxed">
                Определение категорий устойчивости атмосферы по методам{" "}
                <span className="font-medium text-foreground">Паскуилла – Тернера</span> и{" "}
                <span className="font-medium text-foreground">Паскуилла – Фогта</span> с расчётом параметра
                вертикальной дисперсии σ<sub>z</sub>(r) по эмпирическим константам таблицы № 8.
              </p>
            </div>
          </div>
        </header>

        <StabilityCalculator />

        <footer className="mt-12 border-t pt-6 text-xs text-muted-foreground leading-relaxed">
          <p className="max-w-3xl text-pretty">
            Расчёт выполняется в соответствии с методикой Руководства по безопасности
            «Мониторинг гидрологических, метеорологических и аэрологических условий в районах размещения
            объектов использования атомной энергии» (РБ-046-21), утверждённого приказом Ростехнадзора от
            01.02.2021 № 31. Таблицы № 2–8 Приложения № 3.
          </p>
        </footer>
      </div>
    </main>
  )
}
